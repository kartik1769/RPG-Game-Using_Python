import pygame
LOAD_START_SCENE = pygame.event.Event(pygame.USEREVENT, name="Start Game")
LOAD_PAUSE_SCENE = pygame.event.Event(pygame.USEREVENT, name="Pause Game")
LOAD_NEW_GAME_SCENE = pygame.event.Event(pygame.USEREVENT, name="New Game")
LOAD_GAMEOVER_SCENE = pygame.event.Event(pygame.USEREVENT, name="Game_Over")
LOAD_QUIT = pygame.event.Event(pygame.QUIT, name="Quit")
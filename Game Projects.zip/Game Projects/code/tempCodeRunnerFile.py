        # self.check_death()
